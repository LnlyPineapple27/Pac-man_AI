# Pac-man_AI (Project01_Search)
- Members:
	+ Trinh Minh Thanh - 18127217
	+ Phan Tan Dat - 18127078
	+ Tran Phuoc Loc - 18127130
  	+ Tran Ngoc Bao Tran - 18127234
